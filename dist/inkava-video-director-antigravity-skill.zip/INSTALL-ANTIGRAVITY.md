# Install for Antigravity (INKAVA Video Director 2.1.0)

This archive contains one folder, inkava-video-director/, with SKILL.md, references/, scripts/, runtime/ and upstream/.

Extract it so that SKILL.md ends up at one of these paths:

| Scope | Location |
|---|---|
| Global (current documented path) | ~/.gemini/config/skills/inkava-video-director/SKILL.md |
| Workspace | <project>/.agents/skills/inkava-video-director/SKILL.md |
| Legacy global (standalone IDE) | ~/.gemini/antigravity/skills/inkava-video-director/SKILL.md |

macOS / Linux example:

    mkdir -p ~/.gemini/config/skills
    unzip inkava-video-director-antigravity-skill.zip -d ~/.gemini/config/skills

Keep references/ beside SKILL.md. Start a new agent session, then check that the skill appears in Antigravity's customization view.

Licence note: the bundle includes adapted SeeCut helpers under PolyForm Noncommercial 1.0.0
(see inkava-video-director/upstream/seecut/LICENSE). Installation does not grant commercial rights.
FFmpeg, runtime dependencies, official brand fonts, the production logo and any service accounts are not included.
